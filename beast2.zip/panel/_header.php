<?php
// This file is included at the top of all admin pages
require_once __DIR__ . '/../includes/helpers.php';
requireAdmin(); // This checks if user is logged in AND is_admin == 1

$current_page = basename($_SERVER['PHP_SELF']);

// Check for forced password change
if (isset($_SESSION['force_pass_change']) && $_SESSION['force_pass_change'] === true) {
    if ($current_page != 'settings.php') {
        redirect(SITE_URL . '/panel/settings.php?notice=change_password');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?php echo $GLOBALS['settings']['site_name'] ?? 'SubHub'; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css?v=2.2">
    <link rel="stylesheet" href="../assets/css/admin.css?v=2.2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <?php
        $theme_primary = $GLOBALS['settings']['theme_primary'] ?? '#E50914';
        $theme_hover = $GLOBALS['settings']['theme_hover'] ?? '#f40612';
    ?>
    <style>
        :root {
            --brand-red: <?php echo $theme_primary; ?>;
            --brand-red-hover: <?php echo $theme_hover; ?>;
        }
        .admin-logo .site-logo {
             max-height: 40px; /* Admin logo ka size */
             width: auto;
        }
        .nav-section-title, .menu-header {
            padding: 10px 1.5rem 5px;
            color: var(--admin-text-muted);
            font-size: 0.8rem;
            text-transform: uppercase;
            margin-top: 10px;
        }
        .admin-nav .fas {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* --- NAYA CSS: Loading Spinner ke liye --- */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.75);
            display: none; /* Default hidden */
            justify-content: center;
            align-items: center;
            z-index: 9999;
            color: white;
            font-family: Arial, sans-serif;
            flex-direction: column;
        }
        .loading-overlay.active {
            display: flex; /* Show when active */
        }
        .loading-spinner {
            border: 8px solid #f3f3f3;
            border-top: 8px solid var(--brand-red, #E50914); /* Theme color istemal karega */
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
        }
        .loading-overlay p {
            margin-top: 20px;
            font-size: 1.2rem;
            letter-spacing: 1px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        /* Naye Sync Button ka Style */
        .btn-sync {
            background-color: #28a745;
            color: white;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
            border: none;
            font-size: 14px;
        }
        .btn-sync:hover {
            background-color: #218838;
        }
        
        .cron-command {
            display: block;
            background: #222;
            color: #00ff00; /* Green text */
            padding: 8px 12px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 0.85rem;
            margin-top: 10px;
            word-break: break-all;
        }
        
        /* --- NAYA CSS: SMM Order Page ke liye --- */
        .admin-table .action-buttons form {
            margin-bottom: 5px; /* Buttons ke beech thora gap */
        }
        .btn-action {
            width: 100%;
            padding: 6px 10px;
            font-size: 0.8rem;
            font-weight: 600;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .btn-info { background-color: #007bff; color: white; }
        .btn-info:hover { background-color: #0069d9; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-success:hover { background-color: #218838; }
        
        .smm-counts {
            font-family: monospace;
            font-size: 1.1rem;
            font-weight: 600;
        }
        .smm-counts .start { color: #007bff; }
        .smm-counts .remains { color: #28a745; }
        /* --- NAYA CSS KHATAM --- */
    </style>
</head>
<body>

    <div class="loading-overlay" id="loading-overlay">
        <div class="loading-spinner"></div>
        <p id="loading-text">Loading... Please wait...</p>
    </div>
    <header class="admin-header">
        <div class="admin-logo">
            <a href="index.php">
                <?php if (!empty($GLOBALS['settings']['site_logo'])): ?>
                    <img src="../assets/img/<?php echo sanitize($GLOBALS['settings']['site_logo']); ?>?v=<?php echo time(); ?>" 
                         alt="<?php echo sanitize($GLOBALS['settings']['site_name']); ?> Logo" 
                         class="site-logo">
                <?php else: ?>
                    <?php echo sanitize($GLOBALS['settings']['site_name']); // Fallback text ?>
                <?php endif; ?>
            </a>
        </div>
        <div class="admin-user-menu">
            <span>Welcome, <?php echo sanitize($_SESSION['email']); ?></span>
            <a href="../logout.php">Logout</a>
        </div>
    </header>
    
    <div class="admin-wrapper">
        <nav class="admin-nav">
            <ul>
                <li><a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>"><i class="fas fa-home"></i>Dashboard Hub</a></li>
                
                <li class="nav-section-title">Sales</li>
                <li><a href="payments.php" class="<?php echo ($current_page == 'payments.php') ? 'active' : ''; ?>"><i class="fas fa-money-check-alt"></i>Payments</a></li>
                <li><a href="email_log.php" class="<?php echo ($current_page == 'email_log.php') ? 'active' : ''; ?>"><i class="fas fa-envelope-open-text"></i>Email Log</a></li>
                
                <li class="nav-section-title">Subscriptions</li>
                <li><a href="sub_dashboard.php" class="<?php echo ($current_page == 'sub_dashboard.php') ? 'active' : ''; ?>"><i class="fas fa-chart-line"></i>Sub. Dashboard</a></li>
                <li><a href="categories.php" class="<?php echo ($current_page == 'categories.php') ? 'active' : ''; ?>"><i class="fas fa-tags"></i>Sub. Categories</a></li>
                <li><a href="products.php" class="<?php echo ($current_page == 'products.php' || $current_page == 'variations.php') ? 'active' : ''; ?>"><i class="fas fa-box-open"></i>Sub. Products</a></li>
                <li><a href="orders.php" class="<?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>"><i class="fas fa-file-invoice-dollar"></i>Sub. Orders</a></li>
                
                <li class="menu-header">SMM Panel Management</li>
                <li>
                    <a href="smm_dashboard.php" class="<?php echo ($current_page == 'smm_dashboard.php') ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> SMM Dashboard
                    </a>
                </li>
                <li>
                    <a href="providers.php" class="<?php echo ($current_page == 'providers.php') ? 'active' : ''; ?>">
                        <i class="fas fa-plug"></i> API Providers
                    </a>
                </li>
                <li>
                    <a href="smm_categories.php" class="<?php echo ($current_page == 'smm_categories.php') ? 'active' : ''; ?>">
                        <i class="fas fa-icons"></i> SMM Categories
                    </a>
                </li>
                <li>
                    <a href="smm_services.php" class="<?php echo (in_array($current_page, ['smm_services.php', 'smm_edit_service.php'])) ? 'active' : ''; ?>"> 
                        <i class="fas fa-list-alt"></i> SMM Services
                    </a>
                </li>
                <li>
                    <a href="smm_orders.php" class="<?php echo ($current_page == 'smm_orders.php') ? 'active' : ''; ?>">
                        <i class="fas fa-history"></i> SMM Orders
                    </a>
                </li>
                <li>
                    <a href="smm_logs.php" class="<?php echo ($current_page == 'smm_logs.php') ? 'active' : ''; ?>">
                        <i class="fas fa-bug"></i> SMM Logs
                    </a>
                </li>
                <li class="nav-section-title">System & Tools</li>
                <li>
                    <a href="cron_jobs.php" class="<?php echo ($current_page == 'cron_jobs.php') ? 'active' : ''; ?>">
                        <i class="fas fa-clock"></i> Cron Job Manager
                    </a>
                </li>
                <li><a href="users.php" class="<?php echo ($current_page == 'users.php') ? 'active' : ''; ?>"><i class="fas fa-users"></i>Users</a></li>
                <li><a href="methods.php" class="<?php echo ($current_page == 'methods.php') ? 'active' : ''; ?>"><i class="fas fa-credit-card"></i>Pay Methods</a></li>
                <li><a href="wheel_prizes.php" class="<?php echo ($current_page == 'wheel_prizes.php') ? 'active' : ''; ?>"><i class="fas fa-bullseye"></i>Spin Wheel</a></li>
                <li><a href="settings.php" class="<?php echo ($current_page == 'settings.php') ? 'active' : ''; ?>"><i class="fas fa-cog"></i>Settings</a></li>
              </ul>
        </nav>
        
        <main class="admin-content">
            <div class="admin-container">