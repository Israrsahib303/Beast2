</div> </main> </div> <script>
    document.addEventListener('DOMContentLoaded', function() {
        const overlay = document.getElementById('loading-overlay');
        const loadingText = document.getElementById('loading-text');
        
        // Live SMM Status Check Buttons
        const checkButtons = document.querySelectorAll('.btn-live-check');
        
        checkButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const orderId = this.dataset.orderId;
                const originalBtnText = this.innerHTML;
                const loadingBtnText = this.dataset.loadingText || 'Checking...';

                // Loading state dikhayein
                this.disabled = true;
                this.innerHTML = loadingBtnText;
                if (overlay) {
                    loadingText.textContent = 'Checking Status for Order #' + orderId + '...';
                    overlay.classList.add('active');
                }

                // AJAX call karein
                fetch(`api_smm_order_check.php?id=${orderId}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        // Loading state hatayein
                        this.disabled = false;
                        this.innerHTML = originalBtnText;
                        if (overlay) overlay.classList.remove('active');

                        // Result dikhayein
                        if (data.success) {
                            alert('Success: ' + data.message);
                            window.location.reload(); // Page refresh karein taake nayi details dikhe
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        // Loading state hatayein
                        this.disabled = false;
                        this.innerHTML = originalBtnText;
                        if (overlay) overlay.classList.remove('active');
                        
                        console.error('Fetch Error:', error);
                        alert('An error occurred while communicating with the server. Check console.');
                    });
            });
        });
        
    });
    </script>
    </body>
</html>