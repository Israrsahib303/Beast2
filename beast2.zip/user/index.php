<?php
include '_header.php'; // Header file ko include karein

// --- Stats ke liye SQL Queries ---
$user_id = $_SESSION['user_id'];
$stmt_spent = $db->prepare("SELECT SUM(total_price) as total_spent FROM orders WHERE user_id = ? AND (status = 'completed' OR status = 'expired')");
$stmt_spent->execute([$user_id]);
$total_spent = $stmt_spent->fetchColumn() ?? 0;
$stmt_orders = $db->prepare("SELECT COUNT(id) as total_orders FROM orders WHERE user_id = ?");
$stmt_orders->execute([$user_id]);
$total_orders = $stmt_orders->fetchColumn() ?? 0;
$stmt_active = $db->prepare("SELECT COUNT(id) as total_active FROM orders WHERE user_id = ? AND status = 'completed'");
$stmt_active->execute([$user_id]);
$total_active = $stmt_active->fetchColumn() ?? 0;

// --- Category Filter Logic ---
$category_filter = $_GET['category_id'] ?? 'all';
$sql_where = "";
if ($category_filter != 'all' && is_numeric($category_filter)) {
    $sql_where = " AND p.category_id = " . (int)$category_filter;
}
$stmt_cats = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC, name ASC");
$categories = $stmt_cats->fetchAll();
$stmt_prods = $db->query("
    SELECT p.*
    FROM products p
    WHERE p.is_active = 1 $sql_where
    ORDER BY p.name ASC
");
$products = $stmt_prods->fetchAll();
?>

<style>
/* --- Animation Keyframes --- */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
@keyframes liveGradient {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}
@keyframes iconFloat {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-3px); }
    100% { transform: translateY(0px); }
}

/* --- New Dashboard UI --- */
.main-wallet-card {
    background: var(--gradient-1);
    background-size: 200% 200%;
    border-radius: 20px;
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    box-shadow: 0 10px 25px rgba(0,0,0,0.3);
    position: relative;
    overflow: hidden;
    
    /* Animation: 0.5s fade-in, uske baad 4s ka gradient animation */
    opacity: 0;
    animation: fadeInUp 0.5s ease-out 0.2s forwards, 
                 liveGradient 4s ease-in-out infinite 1s;
}
.main-wallet-card::after {
    content: ''; position: absolute; top: -50%; right: -20%; width: 80%; height: 150%;
    background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><path d="M0 80 L80 0 L80 80 Z" fill="rgba(255,255,255,0.05)" /></svg>');
    opacity: 0.3; transform: rotate(20deg);
}
.main-wallet-info p { font-size: 0.9rem; color: #fff; opacity: 0.8; margin: 0; }
.main-wallet-info h2 { font-size: 2.2rem; font-weight: 700; color: #fff; margin: 0.25rem 0 0 0; }
.btn-add-funds-main {
    background: rgba(255, 255, 255, 0.2); color: #fff; padding: 0.8rem 1.2rem;
    border-radius: 50px; font-size: 0.9rem; font-weight: 600; text-decoration: none;
    transition: background 0.2s ease; white-space: nowrap; position: relative; z-index: 2;
}
.btn-add-funds-main:hover { background: rgba(255, 255, 255, 0.3); }

/* Stats Summary Card */
.stats-summary-card {
    background: var(--card-color); border-radius: 15px; padding: 1.25rem;
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem;
    border: 1px solid var(--card-border); margin-bottom: 2.5rem;
    
    opacity: 0;
    animation: fadeInUp 0.5s ease-out 0.4s forwards;
}
.summary-item { display: flex; align-items: center; gap: 0.75rem; }
.summary-item-icon {
    width: 40px; height: 40px; border-radius: 10px; display: grid;
    place-items: center; flex-shrink: 0;
    animation: iconFloat 4s ease-in-out infinite; /* Live float animation */
}
.summary-item:nth-child(2) .summary-item-icon { animation-delay: 0.5s; }
.summary-item:nth-child(3) .summary-item-icon { animation-delay: 1s; }
.summary-item-icon svg { width: 20px; height: 20px; color: #fff; }
.icon-spent { background: linear-gradient(135deg, #0D6EFD 0%, #0550c3 100%); }
.icon-orders { background: linear-gradient(135deg, #fd7e14 0%, #e65c00 100%); }
.icon-active { background: linear-gradient(135deg, #198754 0%, #0f5132 100%); }
.summary-item-info { overflow: hidden; }
.summary-item-info p { font-size: 0.8rem; color: var(--text-muted); margin: 0; font-weight: 500; }
.summary-item-info h3 { font-size: 1.2rem; font-weight: 700; color: var(--text-color); margin: 0.25rem 0 0 0; }

/* Category Dropdown */
.category-filter {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
    align-items: center;
}
.category-filter label {
    font-size: 1.3rem;
    font-weight: 600;
    color: var(--text-color);
    margin: 0;
}
.category-filter select {
    background: var(--card-color);
    color: var(--text-color);
    border: 1px solid var(--card-border);
    padding: 0.5rem 1rem;
    border-radius: var(--radius);
    font-size: 1rem;
    font-weight: 600;
}

/* Mobile responsive */
@media (max-width: 768px) {
    .main-wallet-info h2 { font-size: 1.8rem; }
    .stats-summary-card { grid-template-columns: 1fr; }
    .category-filter { flex-direction: column; align-items: stretch; }
}

/* Z-Index Bug Fix */
@media (max-width: 900px) {
    .nav-links.active {
        z-index: 9999 !important; /* Menu ko sab se upar rakhein */
    }
}
</style>
<div class="main-wallet-card">
    <div class="main-wallet-info">
        <p>Total Balance</p>
        <h2><?php echo formatCurrency($user_balance); ?></h2>
    </div>
    <a href="add-funds.php" class="btn-add-funds-main">+ Add Funds</a>
</div>
<h1 class="section-title" style="margin-bottom: 1rem; font-size: 1.3rem;">Your Stats</h1>
<div class="stats-summary-card">
    <div class="summary-item">
        <div class="summary-item-icon icon-spent">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
        </div>
        <div class="summary-item-info">
            <p>Total Spent</p>
            <h3><?php echo formatCurrency($total_spent); ?></h3>
        </div>
    </div>
    <div class="summary-item">
        <div class="summary-item-icon icon-orders">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
        </div>
        <div class="summary-item-info">
            <p>Total Orders</p>
            <h3><?php echo $total_orders; ?></h3>
        </div>
    </div>
    <div class="summary-item">
        <div class="summary-item-icon icon-active">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div class="summary-item-info">
            <p>Active</s</p>
            <h3><?php echo $total_active; ?></h3>
        </div>
    </div>
</div>
<div class="on-demand-box">
    <div class="demand-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 18h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2z"></path><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2z"></path><path d="M12 12v-2"></path><path d="M12 18v-2"></path></svg>
    </div>
    <div class="demand-content">
        <h3>Looking for another tool?</h3>
        <p>Can't find the subscription you need? Let us know, and we'll try our best to arrange it for you!</p>
        <textarea id="tool-request-text" class="form-control" placeholder="e.g., 'I need Adobe Premiere Pro 1-Year subscription...'"></textarea>
        <button id="send-request-btn" class="btn" data-admin-whatsapp="<?php echo sanitize($GLOBALS['settings']['whatsapp_number'] ?? ''); ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M1.161 21.512L1.16 21.513l-.001-.001h.001Z"/><path d="M12.041 2.12c-5.405 0-9.803 4.398-9.803 9.803 0 2.05.632 3.96 1.71 5.568L2.01 22.82l5.33-1.926c1.531.936 3.32 1.488 5.2 1.488h.001c5.404 0 9.802-4.398 9.802-9.803 0-5.404-4.398-9.802-9.802-9.802Zm0 1.634c4.52 0 8.168 3.648 8.168 8.168 0 4.52-3.648 8.168-8.168 8.168h-.001c-1.74 0-3.37-.545-4.73-1.508l-.337-.202-3.52 1.272 1.294-3.428-.22-.35c-1.04-1.66-1.604-3.58-1.604-5.65 0-4.52 3.648-8.168 8.168-8.168Zm4.163 9.535c-.22-.11-.937-.463-1.082-.515-.145-.053-.25-.08-.356.08-.105.16-.41.516-.502.62-.092.106-.184.12-.328.04-.145-.08-.61-.225-1.164-.716-.43-.38-.72-.857-.807-.998-.086-.14-.009-.217.07-.291.07-.066.16-.18.24-.27.08-.09.105-.16.158-.262.053-.105.026-.187-.013-.268-.04-.08-.356-.856-.488-1.173-.13-.317-.263-.274-.355-.28-.093-.005-.198-.005-.304-.005-.105 0-.276.04-.418.192-.14.15-.53.516-.53 1.258 0 .742.544 1.46.62 1.562.076.105 1.05 1.69 2.542 2.39 1.49 1.13 2.12.906 2.5.856.38-.052 1.187-.483 1.353-.95.167-.468.167-.865.117-.95-.05-.086-.157-.132-.328-.24Z"/></svg>
            Send Request on WhatsApp
        </button>
    </div>
</div>
<div class="category-filter">
    <label for="category-select">View Products:</label>
    <form action="index.php" method="GET" id="category-form">
        <select name="category_id" id="category-select" class="form-control" onchange="document.getElementById('category-form').submit();">
            <option value="all" <?php echo ($category_filter == 'all') ? 'selected' : ''; ?>>All Categories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>" <?php echo ($category_filter == $cat['id']) ? 'selected' : ''; ?>>
                    <?php echo sanitize($cat['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
</div>
<div class="product-grid">
    <?php if (empty($products)): ?>
        <p>No products found in this category.</p>
    <?php else: ?>
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <div class="product-card-icon">
                    <img src="../assets/img/icons/<?php echo sanitize($product['icon']); ?>" alt="<?php echo sanitize($product['name']); ?>">
                </div>
                <div class="product-card-body">
                    <h3 class="product-card-title"><?php echo sanitize($product['name']); ?></h3>
                    
                    <div class="card-heading-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8"iy2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        <span>Description</span>
                    </div>
                    <p class="product-card-description">
                        <?php 
                        if (!empty($product['description'])) {
                            echo nl2br(sanitize($product['description']));
                        } else {
                            echo "No description provided.";
                        }
                        ?>
                    </p>
                    
                    <?php if (!empty($product['proof_link'])): ?>
                        <a href="<?php echo sanitize($product['proof_link']); ?>" class="product-card-proof-link" target="_blank">
                            Check Original Price
                        </a>
                    <?php endif; ?>
                    
                    <a href="checkout.php?product_id=<?php echo $product['id']; ?>" class="btn btn-primary btn-buy" style="margin-top: auto;">
                        View Options & Prices
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include '_footer.php'; ?>